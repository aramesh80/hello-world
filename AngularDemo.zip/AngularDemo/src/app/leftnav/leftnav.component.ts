import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-leftnav',
  templateUrl: './leftnav.component.html',
  styleUrls: ['./leftnav.component.css']
})
export class LeftnavComponent implements OnInit {
  
  @Input()  navList = [];

  @Input()  navTitle: string = "";

  constructor(private router: Router) { }

  ngOnInit() {
  }

  loadsubpages(item) {
  	//let rpath = `/${item.routepath}`;
  	this.router.navigate([`/${item.routepath}`])
      	
  }


}
