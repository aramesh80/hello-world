export class Student {
	name: string = "";
	class: string = "";

}
