/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { PrlComponent } from './prl.component';

describe('PrlComponent', () => {
  let component: PrlComponent;
  let fixture: ComponentFixture<PrlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
