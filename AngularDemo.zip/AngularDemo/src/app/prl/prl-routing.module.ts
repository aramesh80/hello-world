import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PrlComponent } from './prl.component';
const routes: Routes = [
	{ 
	  path: "", 
	  component: PrlComponent
	}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class PrlRoutingModule { 
	/*
		, 
	  children: [
	  	{ path: "moc", loadChildren:"app/om/moc/moc.module#MocModule"},
	  	{ path: "gq", loadChildren:"app/om/gq/gq.module#GqModule"},
	  	{ path: "ct", loadChildren:"app/om/ct/ct.module#CtModule"},
	  	{ path: "opm", loadChildren:"app/om/opm/opm.module#OpmModule"}
	  ]
	*/

}
