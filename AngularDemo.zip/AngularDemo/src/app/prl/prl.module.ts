import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrlRoutingModule } from './prl-routing.module';
import { SharedModule } from '../shared/shared.module';

import { PrlComponent } from './prl.component';

@NgModule({
  imports: [
    CommonModule,
    PrlRoutingModule,
    SharedModule
  ],
  declarations: [
    PrlComponent
  ]
})
export class PrlModule { }
