import { Component, OnInit } from '@angular/core';

import { LeftnavComponent } from '../leftnav/leftnav.component';

@Component({
  selector: 'app-prl',
  templateUrl: './prl.component.html',
  styleUrls: ['./prl.component.css']
})
export class PrlComponent implements OnInit {
	prlTitle: string = "Pay Roll";
	prlNavlist = [
		{ "routepath": "/om/moc", "displayname": "PayRoll-1" },
		{ "routepath": "/om/gq", "displayname": "PayRoll-2" },
		{ "routepath": "/om/ct", "displayname": "PayRoll-3" },
		{ "routepath": "/om/opm", "displayname": "PayRoll-4" }
	]

  constructor() { }

  ngOnInit() {
  }

}
