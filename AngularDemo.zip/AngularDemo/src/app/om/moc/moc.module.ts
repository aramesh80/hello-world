import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MocRoutingModule } from './moc-routing.module';
import { MocComponent } from './moc.component';

@NgModule({
  imports: [
    CommonModule,
    MocRoutingModule
  ],
  declarations: [MocComponent]
})
export class MocModule { }
