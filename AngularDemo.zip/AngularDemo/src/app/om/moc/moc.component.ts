import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-moc',
  templateUrl: './moc.component.html',
  styleUrls: ['./moc.component.css']
})
export class MocComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
