import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OpmComponent } from './opm.component';

const routes: Routes = [{ path: '', component: OpmComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class OpmRoutingModule { }
