import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-opm',
  templateUrl: './opm.component.html',
  styleUrls: ['./opm.component.css']
})
export class OpmComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
