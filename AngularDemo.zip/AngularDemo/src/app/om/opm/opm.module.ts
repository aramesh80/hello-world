import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OpmRoutingModule } from './opm-routing.module';
import { OpmComponent } from './opm.component';

@NgModule({
  imports: [
    CommonModule,
    OpmRoutingModule
  ],
  declarations: [OpmComponent]
})
export class OpmModule { }
