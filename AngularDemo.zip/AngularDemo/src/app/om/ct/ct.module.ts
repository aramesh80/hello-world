import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CtRoutingModule } from './ct-routing.module';
import { CtComponent } from './ct.component';

@NgModule({
  imports: [
    CommonModule,
    CtRoutingModule
  ],
  declarations: [CtComponent]
})
export class CtModule { }
