import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ct',
  templateUrl: './ct.component.html',
  styleUrls: ['./ct.component.css']
})
export class CtComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
