/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { GqComponent } from './gq.component';

describe('GqComponent', () => {
  let component: GqComponent;
  let fixture: ComponentFixture<GqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
