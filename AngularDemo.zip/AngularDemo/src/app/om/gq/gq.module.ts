import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GqRoutingModule } from './gq-routing.module';
import { GqComponent } from './gq.component';

@NgModule({
  imports: [
    CommonModule,
    GqRoutingModule
  ],
  declarations: [GqComponent]
})
export class GqModule { }
