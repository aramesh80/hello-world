import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gq',
  templateUrl: './gq.component.html',
  styleUrls: ['./gq.component.css']
})
export class GqComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
