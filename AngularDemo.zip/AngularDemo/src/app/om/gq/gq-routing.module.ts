import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GqComponent } from './gq.component';

const routes: Routes = [
	{ path: '', component: GqComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class GqRoutingModule { }
