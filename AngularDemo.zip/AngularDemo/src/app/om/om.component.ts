import { Component, OnInit } from '@angular/core';

import { LeftnavComponent } from '../leftnav/leftnav.component';

@Component({
  selector: 'app-om',
  templateUrl: './om.component.html',
  styleUrls: ['./om.component.css']
})
export class OmComponent implements OnInit {
  omTitle: string = "Order Management";
  omnavlist = [
  	{ "routepath": "/om/moc", "displayname": "Manual Order Capture" },
  	{ "routepath": "/om/gq", "displayname": "Get Quote" },
    { "routepath": "/om/ct", "displayname": "Create Template" },
  	{ "routepath": "/om/opm", "displayname": "Opportunity Management" }
  ]

  constructor() { }

  ngOnInit() {
  }

}
