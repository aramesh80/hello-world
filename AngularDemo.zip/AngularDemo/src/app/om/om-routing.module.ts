import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OmComponent } from './om.component'

const omroutes: Routes = [
	{ 
	  path: "", 
	  component: OmComponent, 
	  children: [
	  	{ path: "moc", loadChildren:"app/om/moc/moc.module#MocModule"},
	  	{ path: "gq", loadChildren:"app/om/gq/gq.module#GqModule"},
	  	{ path: "ct", loadChildren:"app/om/ct/ct.module#CtModule"},
	  	{ path: "opm", loadChildren:"app/om/opm/opm.module#OpmModule"}
	  ] 
	}
];

@NgModule({
  imports: [RouterModule.forChild(omroutes)],
  exports: [RouterModule],
  providers: []
})
export class OmRoutingModule { }
