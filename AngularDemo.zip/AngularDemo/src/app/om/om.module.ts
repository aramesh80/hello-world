import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OmRoutingModule } from './om-routing.module';
import { SharedModule } from '../shared/shared.module';

import { OmComponent } from './om.component';

@NgModule({
  imports: [
    CommonModule,
    OmRoutingModule,
    SharedModule
  ],
  declarations: [ 
  	OmComponent
  ]
})
export class OmModule { }
